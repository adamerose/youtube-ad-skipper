[https://chrome.google.com/webstore/devconsole](https://chrome.google.com/webstore/devconsole)

[chrome://extensions/](chrome://extensions/)

```
zip -r youtube-ad-skipper.zip youtube-ad-skipper/
```
