# https://chrome.google.com/webstore/devconsole
zip -r youtube-ad-skipper.zip youtube-ad-skipper/
